public class barbanegra extends personajes{
   
    public static void tostring(){
        System.out.println("2. Barbanegra tiene una resistencia de 1300 ,fuerza de 140 posee la fruta yami yami");
          }
}

