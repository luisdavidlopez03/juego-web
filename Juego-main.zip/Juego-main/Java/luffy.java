public class luffy  extends personajes{
    
    public static void tostring(){
    System.out.println("1. Luffy tiene una resistencia de 1500 ,fuerza de 130 posee la fruta gomu gomu");
      }
}
