public class buggy extends personajes{
   
    public static void tostring(){
        System.out.println("4. Buggy tiene una resistencia de 1600 ,fuerza de 120 posee la fruta bara bara");
          }
}
