public class shaks extends personajes{
    
    public static void tostring(){
        System.out.println("3. Shaks tiene una resistencia de 1600 ,fuerza de 170 pero no posse fruta del diablo");
          }
}
