public abstract class personajes {
    int resistencia; 
    int fuerza; 
    String fruta_del_diablo;
    
    public void estado(){
        System.out.println("Resistencia: "+resistencia);
        System.out.println("Fuerza: "+fuerza);
    }
}